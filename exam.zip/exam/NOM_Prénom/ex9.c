#include <stdio.h>
int Vn(int n);
int Un(int n){
    /* A COMPLETER */
}
int Vn(int n){
    /* A COMPLETER */
}
int main() {
    int n;
    scanf("%d", &n);
    printf("U%d: %d, V%d %d\n",n, Un(n),n, Vn(n));
    return 0;
}
