#include <stdio.h>
#include <stdlib.h>
void rentrer_nombre(int * n){
    scanf("%d", n);
}

int *allouer_tableau(int n) {
    /* A COMPLETER */
}
void fill_tableau(int *tab, int n) {
    /* A COMPLETER */
}
int max_tableau(int *tab, int n) {
    /* A COMPLETER */
}
void liberer_tableau(int *tab) {
    /* A COMPLETER */
}
int main() {
    int n;
    scanf("%d", &n);
    int *tab = allouer_tableau(n);
    fill_tableau(tab, n);
    printf("Tableau: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", tab[i]);
    }
    printf("\n");
    int max = max_tableau(tab, n);
    printf("L'élément maximal est %d\n", max);
    liberer_tableau(tab);
    return 0;
}