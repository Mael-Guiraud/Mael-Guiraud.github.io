#ifndef EXERCICE2_H_INCLUDED
#define EXERCICE2_H_INCLUDED
// Structure pour repr�senter une position
struct position {
    int x;
    int y;
};
#define TAILLE_MATRICE 3
struct position calcul_new_position(int matrice[TAILLE_MATRICE][TAILLE_MATRICE], int * instructions, int taille_matrice, int nombre_instructions);
void displayMatrix(int matrice[TAILLE_MATRICE][TAILLE_MATRICE], int taille_matrice);

#endif // EXERCICE2_H_INCLUDED
