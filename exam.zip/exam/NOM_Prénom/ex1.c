#include <stdio.h>

void afficher_entiers_pairs(int n){
    /* A COMPLETER*/
}

int main() {
    int _DO_NOT_TOUCH_;
    scanf("%d", &_DO_NOT_TOUCH_);
    afficher_entiers_pairs(_DO_NOT_TOUCH_);
    return 0;
}