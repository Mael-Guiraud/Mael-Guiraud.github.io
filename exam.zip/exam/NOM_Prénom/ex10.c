#include <stdio.h>

struct Jour{
    /* A COMPLETER EN RESPECTANT LES NOMS UTILISES DANS LE MAIN*/
};
char* jour_le_plus_chaud(struct Jour semaine[7]){
    /* A COMPLETER */
}
char* jour_le_plus_froid(struct Jour semaine[7]){
    /* A COMPLETER */
}
float temperature_max_moyenne(struct Jour semaine[7]){
    /* A COMPLETER */
}
int main() {
    struct Jour semaine[7];
    for (int i = 0; i < 7; i++) {
        scanf("%s %f %f", semaine[i].jour, &semaine[i].temperature_max, &semaine[i].temperature_min);
    }
    printf("Jour le plus chaud: %s\n", jour_le_plus_chaud(semaine));
    printf("Jour le plus froid: %s\n", jour_le_plus_froid(semaine));
    printf("Temperature max moyenne: %.2f\n", temperature_max_moyenne(semaine));
    return 0;
}