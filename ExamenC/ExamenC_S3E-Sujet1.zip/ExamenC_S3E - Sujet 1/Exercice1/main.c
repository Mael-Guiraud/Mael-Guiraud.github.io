#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "./Exercice1.h"

#define SCORE_MAX 5
#define STRING_MAX 32
int main()
{
    int score = 0;
    int score_max=SCORE_MAX;
    char instances[SCORE_MAX][2][STRING_MAX];
    strcpy(instances[0][0], "CATCGTAATGACGGCCT");
    strcpy(instances[0][1], "GAGCCTACTAACGGGAT");
    strcpy(instances[1][0], "GGGAAATTTC");
    strcpy(instances[1][1], "GGGAATTTC");
    strcpy(instances[2][0], "AGCTGAATC");
    strcpy(instances[2][1], "AGCTGAATC");
    strcpy(instances[3][0], "AAAAAAAAC");
    strcpy(instances[3][1], "AAAAAAAAG");
    strcpy(instances[4][0], "A");
    strcpy(instances[4][1], "A");
    int res_attendu[] ={7,-1,0,1,0};
    for(int i=0;i<score_max;i++)
    {
        printf("Test distance de hamming entre \"%s\" et \"%s\"...\n",instances[i][0],instances[i][1]);
        if(hamming(instances[i][0],instances[i][1]) == res_attendu[i]){
            printf("Ok !\n");
            score++;
        }
        else{
            printf("Fail...\n");
        }
    }


    printf("\nVotre programme passe un total de %d/%d tests!\n\n",score,score_max);
    return 0;
}
