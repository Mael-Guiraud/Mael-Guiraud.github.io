#include <stdio.h>

void afficher_produit(int matrix[4][3]){
    /* A COMPLETER */
}
int main() {
    int matrix[4][3];
    int max_in_row;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 3; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
    afficher_produit(matrix);
    return 0;
}
