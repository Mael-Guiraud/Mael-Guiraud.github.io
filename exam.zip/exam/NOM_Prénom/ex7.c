#include <stdio.h>
#include <stdlib.h>
void afficher_somme_diagonale(int** matrix,int n){
    /* A COMPLETER */
}
int main() {
    int n;
    scanf("%d", &n);
    int** matrix=(int**)malloc(n*sizeof(int*));
    int max_in_row;
    for (int i = 0; i < n; i++) {
        matrix[i]=(int*)malloc(n*sizeof(int));
        for (int j = 0; j < n; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
    afficher_somme_diagonale(matrix,n);
    for (int i = 0; i < n; i++) {
        free(matrix[i]);
    }
    free(matrix);
    return 0;
}
