#include <stdio.h>
#include <stdlib.h>
#include "Exercice2.h"
// Fonction pour trouver la position du robot
struct position getPosition(int matrice[TAILLE_MATRICE][TAILLE_MATRICE], int taille_matrice){
    struct position initialPos;
    initialPos.x = -1;
    initialPos.y = -1;
    /****************
     * A COMPLETER *
    ****************/
    return initialPos;
}

// Fonction pour mettre à jour la position du robot selon les instructions
void updatePosition(int matrice[TAILLE_MATRICE][TAILLE_MATRICE], int instruction, int taille_matrice) {
    struct position currentPosition = getPosition(matrice, taille_matrice);
    /****************
     * A COMPLETER *
    ****************/
    
}
// Fonction pour afficher la matrice avec les coordonnées (0,0) en bas à gauche
void displayMatrix(int matrice[TAILLE_MATRICE][TAILLE_MATRICE], int taille_matrice) {
    for (int i = taille_matrice - 1; i >= 0; --i){
            printf("-");
    }
    printf("\n");
    for (int i = taille_matrice - 1; i >= 0; --i) {
        for (int j = 0; j < taille_matrice; ++j) {
            printf("%d",matrice[i][j]);
        }
        printf("\n");
    }
    for (int i = taille_matrice - 1; i >= 0; --i){
            printf("-");
    }
    printf("\n");
    return;
}
// Fonction pour calculer la nouvelle position du robot selon les instructions
struct position calcul_new_position(int matrice[TAILLE_MATRICE][TAILLE_MATRICE], int * instructions, int taille_matrice, int nombre_instructions) {
    

    for (int i = 0; i < nombre_instructions; ++i) {
        updatePosition(matrice, instructions[i], taille_matrice);

    }
    struct position currentPos = getPosition(matrice, taille_matrice);
    return currentPos;
}

