#include <stdio.h>
#include <stdlib.h>
#include "Exercice2.h"

#define SCORE_MAX 8
#define INSTRUCTIONS_MAX 11

int main() {
    int score = 0;
    int score_max = SCORE_MAX;
    int matrices[SCORE_MAX][TAILLE_MATRICE][TAILLE_MATRICE]={
        { {1,0,0},{0,0,0},{0,0,0} },
        { {0,0,1},{0,0,0},{0,0,0} },
        { {0,0,0},{0,0,0},{1,0,0} },
        { {0,0,0},{0,0,0},{0,0,1} },
        { {0,0,0},{0,1,0},{0,0,0} },
        { {0,0,0},{0,0,0},{0,1,0} },
        { {1,0,0},{0,0,0},{0,0,0} },
        { {0,0,0},{0,0,1},{0,0,0} }
    };

    int instructions[SCORE_MAX][INSTRUCTIONS_MAX] = {
        {1, 3, 1, 3},
        {4, 1, 4, 1},
        {3, 3, 2, 2},
        {2, 2, 4, 4},
        {3, 1, 4, 4, 2, 0, 2, 3, 3, 1, 4 },
        {0,0},
        {1,1,3,3,2,2,4,4,0,0},
        {0, 0, 4, 0,4}
    };
    int nb_instructions[SCORE_MAX] = { 4,4,4,4,11,2,10,5};
    int res_attendu[SCORE_MAX][2] = {
        {2, 2},
        {2, 0},
        {0, 2},
        {0, 0},
        {1, 1},
        {2, 1},
        {0, 0},
        {1,0}
    };


    for (int i = 0; i < SCORE_MAX; ++i) {

        struct position result = calcul_new_position(matrices[i], instructions[i], TAILLE_MATRICE, nb_instructions[i]);
        printf("Test position du robot %d...\n", i + 1);
        printf("Attendu : (%d,%d), Resultat : (%d,%d)\n", res_attendu[i][0], res_attendu[i][1], result.x, result.y);
        if (result.x == res_attendu[i][0] && result.y == res_attendu[i][1]) {
            printf("Ok !\n");
            score++;
        } else {
            printf("Fail...\n");
        }
    }

    printf("\nVotre programme passe un total de %d/%d tests!\n\n", score, score_max);
    return 0;
}
