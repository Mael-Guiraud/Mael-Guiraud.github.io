#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "./Exercice3.h"

#define SCORE_MAX 5
#define STRING_MAX 32

int main()
{
    int score = 0;
    int score_max=SCORE_MAX;
    char instances[SCORE_MAX][STRING_MAX];
    strcpy(instances[0], "kayak");
    strcpy(instances[1], "");
    strcpy(instances[2], "a");
    strcpy(instances[3], "palindrome");
    strcpy(instances[4], "radar");

    int res_attendu[] ={1,-1,1,0,1};
    for(int i=0;i<score_max;i++)
    {
        printf("Test pour savoir si \"%s\" est un palindrome...\n",instances[i]);
        if(est_palindrome(instances[i]) == res_attendu[i]){
            printf("Ok !\n");
            score++;
        }
        else{
            printf("Fail...\n");
        }
    }


    printf("\nVotre programme passe un total de %d/%d tests!\n\n",score,score_max);
    return 0;
}
