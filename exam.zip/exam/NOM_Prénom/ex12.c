#include <stdio.h>
#include <stdlib.h>

struct element {
    int valeur;
    struct element *suivant;
};
typedef struct element element;


element* empiler( element* tete, int val){
    /* A COMPLETER */
}
void afficher_pile(element* tete){
    while(tete != NULL){
        printf("%d,",tete->valeur);
        tete=tete->suivant;
    }
    printf("\n");
}

int est_dans_pile(element* tete,int val){
    /* A COMPLETER */
}
void liberer_pile(element* tete){
    /* A COMPLETER */
}
int main(){
    element * tete_liste = NULL;
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        int val;
        scanf("%d",&val);
        tete_liste = empiler(tete_liste,val);
    }
    int val;
    scanf("%d",&val);
    printf("La pile est : ");
    afficher_pile(tete_liste);
    printf("%d\n",est_dans_pile(tete_liste,val));
    liberer_pile(tete_liste);
    return 0;
}
