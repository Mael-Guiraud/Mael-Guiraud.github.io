#include "Exercice3.h"
#include <stdlib.h>
#include <string.h>

    /*******************************************************************************
     * A COMPLETER : Il est vivement recommandé d'utiliser plusieurs fonctions ici.*
    ********************************************************************************/


int est_palindrome(char * str){
    /****************
     * A COMPLETER *
    ****************/
    return A_COMPLETER;
}
