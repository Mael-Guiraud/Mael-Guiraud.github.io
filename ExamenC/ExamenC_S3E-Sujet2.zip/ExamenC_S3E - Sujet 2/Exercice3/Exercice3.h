#ifndef EXERCICE3_H_INCLUDED
#define EXERCICE3_H_INCLUDED
#define A_COMPLETER -2
struct elem{
    char val;
    struct elem * suiv;
    };

int est_palindrome(char * str);

#endif // EXERCICE3_H_INCLUDED
