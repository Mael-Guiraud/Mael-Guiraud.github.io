#include <stdio.h>

void afficher_max_par_ligne(int matrix[3][3]){
    /* A COMPLETER */
}
int main() {
    int matrix[3][3];
    int max_in_row;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
    afficher_max_par_ligne(matrix);
    return 0;
}
