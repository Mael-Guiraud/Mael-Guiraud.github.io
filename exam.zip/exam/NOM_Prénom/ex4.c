#include <stdio.h>

void afficher_somme_alternee(int n){
     /* A COMPLETER */
}

int main() {
    int _DO_NOT_TOUCH_;
    scanf("%d", &_DO_NOT_TOUCH_);
    afficher_somme_alternee(_DO_NOT_TOUCH_);
    return 0;
}