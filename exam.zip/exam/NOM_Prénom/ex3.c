#include <stdio.h>

void afficher_carres(int n){
    /* A COMPLETER */
}

int main() {
    int _DO_NOT_TOUCH_;
    scanf("%d", &_DO_NOT_TOUCH_);
    afficher_carres(_DO_NOT_TOUCH_);
    return 0;
}