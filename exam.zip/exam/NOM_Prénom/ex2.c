#include <stdio.h>

void afficher_somme(int n){
    /* A COMPLETER*/
}

int main() {
    int _DO_NOT_TOUCH_;
    scanf("%d", &_DO_NOT_TOUCH_);
    afficher_somme(_DO_NOT_TOUCH_);
    return 0;
}