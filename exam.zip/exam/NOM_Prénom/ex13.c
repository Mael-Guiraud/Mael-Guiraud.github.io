#include <stdio.h>
#include <stdlib.h>
#include <string.h> // Pour strcpy 

struct element {
    char mot[20];
    struct element *suivant;
};
typedef struct element element;

int est_superieur_lexicographiquement(char* mot1, char* mot2) {
    /* A COMPLETER - INTERDIT D'UTILISER STRCMP*/
}

element* ajouter_trie(element* tete, char* mot) {
    element* nouveau = (element*)malloc(sizeof(element));
    strcpy(nouveau->mot, mot); // Copier la chaîne dans le nouveau noeud
    nouveau->suivant = NULL;
    /* A COMPLETER */
}

void afficher_liste(element* tete) {
    while (tete != NULL) {
        printf("%s ", tete->mot);
        tete = tete->suivant;
    }
    printf("\n");
}

void liberer_liste(element* tete) {
    /* A COMPLETER */
    
}

int main() {
    element* tete_liste = NULL;
    int n;

    printf("Entrez le nombre de mots : ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        char mot[20];
        printf("Entrez le mot %d : ", i + 1);
        scanf("%s", mot);
        tete_liste = ajouter_trie(tete_liste, mot);
    }

    printf("La liste triée est : ");
    afficher_liste(tete_liste);

    liberer_liste(tete_liste);
    return 0;
}
