#include <stdio.h>
#include <stdlib.h>

void init(int * size,int*** matrix){
    FILE* file= fopen("matrice.txt","r");
    printf("Choissisez la taille de la matrice: ");
    scanf("%d",size);
    printf("Matrice de taille: %d\n",*size);
    int ** square_matrix=(int**)malloc(sizeof(int*)*(*size));
    for(int i=0;i<*size;i++){
        square_matrix[i]=(int*)malloc(sizeof(int)*(*size));
    }

    for(int i=0;i<*size;i++){
        for(int j=0;j<*size;j++){
            fscanf(file,"%d",&square_matrix[i][j]);
        }
    }
    fclose(file);
    *matrix=square_matrix;
    return;
}


void close(int **square_matrix,int size){
    for(int i=0;i<size;i++){
        free(square_matrix[i]);
    }
    free(square_matrix);
}

int main()
{
    int size_matrix;
    int ** square_matrix;
    init(&size_matrix,&square_matrix);

    int max = 0;
    /* A COMPLETER
       Lorsque vous lancez le programme, vous pouvez choisir une taille de matrice � g�n�rer.
       Le code se charge de g�n�rer la matrice pour vous.
       Vous devez compl�ter ce code de fa�on � ce que le programme affiche la valeur maximale de la matrice "square_matrix".
       Cette matrice est carr�e de dimmension "size_matrix"x"size_matrix"

    */
    printf("La valeur maximale de la matrice est %d \n",max);
    close(square_matrix,size_matrix);
    return 0;
}
