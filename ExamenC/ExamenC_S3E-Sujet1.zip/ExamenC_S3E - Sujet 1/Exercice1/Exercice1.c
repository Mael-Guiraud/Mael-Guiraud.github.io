#include <string.h>
#include "Exercice1.h"
//Compare et renvoie la distance de hamming entre les chaines de caract�res str1 et str2
//Si str1 et str2 ne font pas la m�me taille, la fonction doit renvoyer -1
int hamming(char* str1, char* str2) {
    /****************
     * A COMPLETER *
    ****************/
    return A_COMPLETER;
}
