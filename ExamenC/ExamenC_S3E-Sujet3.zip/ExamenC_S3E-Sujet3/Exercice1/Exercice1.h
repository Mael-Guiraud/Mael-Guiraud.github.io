#ifndef EXERCICE1_H_INCLUDED
#define EXERCICE1_H_INCLUDED
int hamming(char* str1,char* str2);
#define A_COMPLETER -2
#endif // EXERCICE1_H_INCLUDED
